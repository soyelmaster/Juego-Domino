//--------------------------
#ifndef UCONJUNTOH
#define UCONJUNTOH
//--------------------------
typedef unsigned char byte;
class conjunto
{
   byte z[3];
   public:
       conjunto();
       void insertar(int f, int c);
       void eliminar(int f, int c);
       bool pertenece(int f, int c);
       bool vacio();
       int mayor();
};

//--------------------------
#endif

